# Hala Mobility Inventory V1

A lightweight browser-based MVP for EV two-wheeler parts inventory and repair tracking.

## Included
- Dashboard
- Parts inventory
- Stock In / Stock Out
- Vehicle repair register
- 3PL / B2B / B2C customer types
- Basic reports
- Mobile-friendly layout
- Browser local storage (no server required for this prototype)

## Run
Open `index.html` in a browser.

## GitHub Pages
Create a GitHub repository, upload `index.html` and `README.md`, then enable GitHub Pages from repository Settings → Pages → Deploy from branch.

## Next production upgrades
- Supabase/PostgreSQL database
- Login and user roles
- Multi-location stock transfers
- Parts consumed against each repair
- Purchase orders and GRN
- Excel import/export
- Audit trail
- Photo upload
- Advanced reports
